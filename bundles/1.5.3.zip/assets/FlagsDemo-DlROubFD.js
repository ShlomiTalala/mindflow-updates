import{j as o}from"./index-CP8ojPaN.js";import t from"./GlobeDemo-BQgUNLeS.js";function m(){return o.jsx(t,{withFlag:!0})}export{m as default};
