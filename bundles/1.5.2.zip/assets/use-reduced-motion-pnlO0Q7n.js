import{bu as t,bv as o,r,bw as s}from"./index-BCa5bJ5w.js";function n(){!t.current&&o();const[e]=r.useState(s.current);return e}export{n as u};
