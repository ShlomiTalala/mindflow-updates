import{j as o}from"./index-BCa5bJ5w.js";import t from"./GlobeDemo-C2XCFtmu.js";function m(){return o.jsx(t,{withFlag:!0})}export{m as default};
