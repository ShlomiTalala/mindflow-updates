# Background music — drop your tracks here

The app's music picker (Settings → מוזיקת רקע) tries to load a real audio
file for each track. If the file is missing, it falls back to a
procedurally-generated synth loop (works, but pales next to a real
recording).

## Filenames the app looks for

Save your files as MP3 (or M4A — most browsers support it) at exactly:

```
public/audio/zen_garden.mp3
public/audio/bamboo_forest.mp3
public/audio/tea_ceremony.mp3
public/audio/floating_lotus.mp3
public/audio/rain.mp3
```

Vite serves `/public/...` at the root, so they end up at `/audio/<id>.mp3`
in production. No extra config needed.

## What to look for

Per the Vita Mahjong music spec the app is targeting:

- **Genre**: ambient / zen / light Asian traditional
- **Tempo**: 60–90 BPM, no strong rhythm or percussion
- **Length**: 30–90 s seamless loops are ideal (longer is fine — the app
  uses HTML5 `<audio loop>` so the file repeats, but be sure the file
  itself is mastered to loop without an audible click)
- **Instruments**: pad, soft/felt piano, koto/guzheng, bamboo flute, wind
  chimes, harp
- **Avoid**: vocals, drum kits, big swells, anything attention-grabbing

## Free / royalty-free sources

All of these allow free commercial use, most with no attribution:

| Source | URL | Notes |
| --- | --- | --- |
| Pixabay Music | https://pixabay.com/music/search/zen/ | Search "zen", "koto", "ambient", "meditation". Click track → download MP3. |
| Pixabay Music | https://pixabay.com/music/search/japanese%20ambient/ | Specifically Asian-tinged tracks. |
| Free Music Archive | https://freemusicarchive.org/genre/Ambient/ | Filter to CC0 / CC-BY licenses. |
| Internet Archive | https://archive.org/details/zen-garden-relaxing-music | Long-form CC tracks — good for trimming. |
| Uppbeat | https://uppbeat.io/music/tag/zen | Free tier with attribution. |
| Mixkit | https://mixkit.co/free-stock-music/tag/zen/ | Free, no attribution. |

## Track style suggestions (matches the in-app labels)

- **גן זן (`zen_garden`)** — pure ambient pad, slow koto plucks, occasional
  wind chime. Quietest of the four.
- **יער במבוק (`bamboo_forest`)** — pad with a sparse bamboo flute melody;
  more melodic.
- **טקס תה (`tea_ceremony`)** — felt piano arpeggio, occasional koto.
- **לוטוס צף (`floating_lotus`)** — pure pad atmosphere with gentle bell
  sparkles, no melody.
- **גשם (`rain`)** — gentle steady rain, no music. Search Pixabay for
  "rain", "soft rain", "rain ambient", or "rain on leaves". Avoid tracks
  with thunder, wind, or strong dynamics.

## Looping tip

If your downloaded MP3 has 1–2 s of silence at the start or a fade-in/fade-out
that breaks looping, trim with Audacity → Effect → "Auto-trim silences" and
export as MP3 320 kbps.

## Volume

Mix your file fairly quiet (peaks around -12 dBFS). The app fades it in to
~45% volume, but a hot file will still drown out SFX.
