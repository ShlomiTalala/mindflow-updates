import{c,j as r,m as d,r as i,A as y}from"./index-DnLKMW4g.js";/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]],k=c("Lightbulb",u);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],v=c("MapPin",_);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=[["path",{d:"M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8",key:"1p45f6"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}]],M=c("RotateCw",b);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]],j=c("Target",f);/**
 * @license lucide-react v0.475.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=[["path",{d:"M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"knzxuh"}],["path",{d:"M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"2jd2cc"}],["path",{d:"M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"rd2r6e"}]],$=c("Waves",g);function C({children:s,onClick:n,variant:t="primary",type:e="button",disabled:a=!1,className:p="",ariaLabel:x}){const h="w-full inline-flex items-center justify-center rounded-pill font-bold text-base sm:text-lg py-4 px-8 select-none transition-shadow duration-200 disabled:opacity-50 disabled:cursor-not-allowed",l={primary:"text-cat-cta-fg bg-[linear-gradient(180deg,hsl(24_96%_68%)_0%,hsl(var(--cat-cta))_45%,hsl(19_86%_52%)_100%)] shadow-[inset_0_1px_0_rgba(255,255,255,0.45),0_4px_0_hsl(16_70%_36%),0_10px_20px_-8px_rgba(0,0,0,0.55)]",ghost:"bg-white/10 text-cat-text border border-white/15 hover:bg-white/15",dark:"bg-slate-800 text-white hover:bg-slate-700"};return r.jsx(d.button,{type:e,onClick:n,disabled:a,"aria-label":x,whileTap:a?void 0:t==="primary"?{y:3,boxShadow:"inset 0 1px 0 rgba(255,255,255,0.35), 0 1px 0 hsl(16 70% 36%), 0 4px 10px -6px rgba(0,0,0,0.5)"}:{scale:.97},whileHover:a?void 0:{y:-1},transition:{type:"spring",stiffness:400,damping:28},className:`${h} ${l[t]||l.primary} ${p}`,children:s})}let o=null,m=1;function N(s,n={}){o==null||o({id:m++,text:s,...n})}function L(){const[s,n]=i.useState([]);return i.useEffect(()=>(o=t=>{n(e=>[...e,t]),setTimeout(()=>{n(e=>e.filter(a=>a.id!==t.id))},1100)},()=>{o=null}),[]),r.jsx("div",{className:"pointer-events-none fixed inset-0 z-40 overflow-hidden","aria-hidden":"true",children:r.jsx(y,{children:s.map(t=>{const e=t.x??50+(t.id%5-2)*6,a=t.y??38;return r.jsx(d.span,{initial:{opacity:0,y:14,scale:.7},animate:{opacity:1,y:-46,scale:1.05},exit:{opacity:0,y:-80,scale:.9},transition:{duration:1,ease:[.22,1,.36,1]},className:"absolute font-black text-3xl text-amber-300",style:{left:`${e}%`,top:`${a}%`,transform:"translateX(-50%)",textShadow:"0 2px 10px rgba(0,0,0,0.35)",direction:"ltr"},children:t.text},t.id)})})})}const R=i.createContext(null),P=i.createContext(null);export{L as F,C as L,v as M,R,j as T,$ as W,P as a,k as b,M as c,N as s};
