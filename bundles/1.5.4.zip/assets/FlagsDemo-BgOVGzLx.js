import{j as o}from"./index-DnLKMW4g.js";import t from"./GlobeDemo-CAcbqcil.js";function m(){return o.jsx(t,{withFlag:!0})}export{m as default};
