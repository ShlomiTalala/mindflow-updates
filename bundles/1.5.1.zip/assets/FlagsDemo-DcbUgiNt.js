import{j as o}from"./index-BuwXXmcZ.js";import t from"./GlobeDemo-DQspT3L0.js";function m(){return o.jsx(t,{withFlag:!0})}export{m as default};
