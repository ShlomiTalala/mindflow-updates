import{bi as t,bj as o,r,bk as s}from"./index-BuwXXmcZ.js";function u(){!t.current&&o();const[e]=r.useState(s.current);return e}export{u};
